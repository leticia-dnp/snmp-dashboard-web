# Topologia — Projeto de Redes (Packet Tracer)

Documento gerado a partir da digitalização (decodificação binário → XML → texto) do arquivo `Projeto_de_redes.pkt`, exportado do Cisco Packet Tracer.

## Dispositivos identificados

| Dispositivo | Papel | Endereço IP | Máscara | Gateway |
|---|---|---|---|---|
| PC1 | Estação de trabalho | `192.168.1.10` | `255.255.255.0` (VLAN1) | `192.168.1.1` |
| Switch | Camada 2 (gerenciável), agente SNMP | `192.168.1.1` (VLAN1) | `255.255.255.0` | — |
| PC2 | Estação de monitoramento (host `localhost` = `192.168.1.100`) | `192.168.1.100` | `255.255.255.0` (VLAN1) | `192.168.1.1` |

## Conexão relevante com o projeto SNMP

O `Switch` está com o SNMP **habilitado em modo somente leitura** (`RO`), community `public`:

```
snmp-server community public RO
```

Isso confirma que este é o dispositivo-alvo que a aplicação web (`snmp-dashboard-web`) deve consultar via `snmpget`/`snmpwalk` para obter os 5 itens da MIB-2 (`sysDescr`, `sysUpTime`, `sysContact`, `sysName`, `sysLocation`).

## Configuração completa do Switch (running-config extraída)

Ver arquivo [`switch-running-config.txt`](./switch-running-config.txt) — configuração Cisco IOS completa, extraída diretamente do arquivo `.pkt`.

## Arquivos deste diretório

| Arquivo | Descrição |
|---|---|
| `switch-running-config.txt` | Running-config do Switch em texto puro (formato Cisco IOS), pronta para reaplicar em um dispositivo real/simulado |
| `topologia-completa.xml` | Projeto Packet Tracer completo, decodificado do binário `.pkt` original para XML legível (inclui todos os dispositivos, cabos, posições e configurações) |
| `topologia.md` | Este documento — resumo da topologia e do papel de cada dispositivo |

## Como a digitalização foi feita

O arquivo `.pkt` do Cisco Packet Tracer usa um formato **binário proprietário e criptografado**. Para extrair o conteúdo em texto/código, o binário foi decodificado para XML e, a partir dele, as configurações (`running-config`) e os parâmetros de rede de cada dispositivo foram extraídos e organizados neste diretório.

> ⚠️ O arquivo `.pkt` original continua sendo a fonte oficial do projeto (deve ser mantido no repositório para abertura no próprio Packet Tracer). Os arquivos acima são uma **representação textual/digitalizada** de seu conteúdo, para leitura, versionamento (`git diff`) e documentação no GitHub.
